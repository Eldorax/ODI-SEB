<?php

/* default/home.html.twig */
class __TwigTemplate_a5c20c6447c3253f96a0f80caa24cb65eca9d005a649ccd1fb85e1f3368496fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Accueil

";
    }

    public function getTemplateName()
    {
        return "default/home.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* Accueil*/
/* */
/* */
