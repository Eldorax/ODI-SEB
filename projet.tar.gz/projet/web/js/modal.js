$('#myModal').on('hide.bs.modal', function() {
    $(this).removeData();
  });
